package com.indra.base.bootloader;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootloaderApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootloaderApplication.class, args);
	}

}
