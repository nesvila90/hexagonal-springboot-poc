package com.indra.base.bootloader;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootloaderApplicationTests {

	@Test
	void contextLoads() {
	}

}
