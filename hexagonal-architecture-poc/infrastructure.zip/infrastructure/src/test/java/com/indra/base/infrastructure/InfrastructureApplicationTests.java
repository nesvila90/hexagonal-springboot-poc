package com.indra.base.infrastructure;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfrastructureApplicationTests {

	@Test
	void contextLoads() {
	}

}
